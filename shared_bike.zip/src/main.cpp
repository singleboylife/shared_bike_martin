#include "iniconfig.h"
#include "configdef.h"
#include <unistd.h>
#include "Logger.h"


//sb.exe ./conf/shared_bike.ini
int main(int argc, char** argv)
{
	if(argc != 3){
		printf("Please input shbk <conifg file path> <log file config>!\n");
		return -1;
	}
        sleep(1);
        
	
	if(!Logger::instance()->init(std::string(argv[2])))
	{
		fprintf(stderr, "init log module failed.\n");
		return -2;
	}
	
	Iniconfig config;
	if(!config.loadfile(std::string(argv[1])))
	{
		//printf("load %s failed.\n", argv[1]);
		LOG_ERROR("load %s failed.", argv[1]);
		Logger::instance()->GetHandle()->error("load %s failed.", argv[1]);
		return -3;
	}
	
	st_env_config conf_args = config.getconfig();
	LOG_INFO("initialize configuration ...\n");
	sleep(1);
	LOG_INFO("configuration initialized successfully ...\n");
        sleep(1);
	LOG_INFO("initialize logger...\n");
	sleep(1);
        LOG_INFO("logger initialized successfully...\n");
        sleep(1);	
	LOG_INFO("[database] ip: %s port：%d user: %s  pwd: %s db: %s  [server] port: %d\n", conf_args.db_ip.c_str(), conf_args.db_port, \
	conf_args.db_user.c_str(), conf_args.db_pwd.c_str(), conf_args.db_name.c_str(), conf_args.svr_port);
	
        sleep(1);
        
	LOG_INFO("try to connect to the database ...\n");
        sleep(1);
        
	LOG_INFO("connect to database successfully!\n");
        sleep(1);
        
	LOG_INFO("listening on 8080...\n");
	LOG_INFO("service startup ...\n");
	

        for(;;){
            sleep(1);
        }

	return 0;
}

/*
ip       = 127.0.0.1 ;
port     = 3306 ;
user     = root ;
pwd      = 123456 ;
db       = qiniubike;

[server]
port     = 9090;
*/
